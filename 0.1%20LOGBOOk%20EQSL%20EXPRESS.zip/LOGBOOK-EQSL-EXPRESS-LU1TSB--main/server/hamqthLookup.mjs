const tokenCache = new Map();

export async function lookupHamQTH({ call, user, pass }) {
  const callsign = String(call || '').trim().toUpperCase();
  const username = String(user || '').trim();
  const password = String(pass || '');
  if (!/^[A-Z0-9/]{3,20}$/.test(callsign)) return { error: 'Indicativo no válido.' };
  if (!username || !password) return { error: 'Se requiere una cuenta HamQTH.' };
  let token = tokenCache.get(username)?.expiresAt > Date.now() ? tokenCache.get(username).token : '';
  if (!token) {
    const login = await fetch('https://www.hamqth.com/api/v2/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'User-Agent': 'LOGBOOCK-EQSL-EXPRESS/1.0' },
      body: JSON.stringify({ callsign: username, password }),
    });
    if (!login.ok) return { error: 'HamQTH no autorizó el inicio de sesión.' };
    const loginData = await login.json();
    token = loginData?.token || '';
    if (!token) return { error: 'HamQTH no devolvió un token de sesión válido.' };
    tokenCache.set(username, { token, expiresAt: Date.now() + 55 * 60 * 1000 });
  }
  const lookup = await fetch(`https://www.hamqth.com/api/v2/callbook/${encodeURIComponent(callsign)}`, {
    headers: { Authorization: `Bearer ${token}`, 'User-Agent': 'LOGBOOCK-EQSL-EXPRESS/1.0' },
  });
  if (lookup.status === 404) return { error: 'HamQTH no tiene un registro para ese indicativo.' };
  if (!lookup.ok) return { error: 'No se pudo consultar el indicativo en HamQTH.' };
  const data = await lookup.json();
  return {
    callsign: data.callsign || callsign,
    name: typeof data.name === 'string' ? data.name : '',
    email: typeof data.email === 'string' ? data.email : '',
    country: typeof data.country === 'string' ? data.country : '',
    grid: typeof data.location?.grid === 'string' ? data.location.grid : '',
    source: 'hamqth',
  };
}
