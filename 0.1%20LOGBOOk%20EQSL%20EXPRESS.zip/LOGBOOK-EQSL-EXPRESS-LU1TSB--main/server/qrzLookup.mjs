function decodeXml(value = '') {
  return value.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&').trim();
}
function field(xml, name) {
  const match = xml.match(new RegExp(`<${name}>([\\s\\S]*?)<\\/${name}>`, 'i'));
  return match ? decodeXml(match[1].replace(/<[^>]+>/g, '')) : '';
}
export async function lookupCallsign({ call, user, pass }) {
  const callsign = String(call || '').trim().toUpperCase();
  const username = String(user || '').trim();
  const password = String(pass || '');
  if (!/^[A-Z0-9/]{3,16}$/.test(callsign)) return { error: 'Indicativo no válido.' };
  if (!username || !password) return { error: 'Se requiere una cuenta QRZ con acceso a la API XML.' };

  const authParams = new URLSearchParams({ username, password, agent: 'LOGBOOCK-EQSL-EXPRESS/1.0' });
  const authRes = await fetch('https://xmldata.qrz.com/xml/current/', { method: 'POST', headers: { 'User-Agent': 'LOGBOOCK-EQSL-EXPRESS/1.0', 'Content-Type': 'application/x-www-form-urlencoded' }, body: authParams.toString() });
  if (!authRes.ok) return { error: 'QRZ no está disponible en este momento.' };
  const authXml = await authRes.text();
  const key = field(authXml, 'Key');
  const authError = field(authXml, 'Error');
  if (!key) return { error: authError || 'QRZ no autorizó la sesión XML. Verificá tu acceso a la API.' };

  const lookupUrl = new URL('https://xmldata.qrz.com/xml/current/');
  lookupUrl.searchParams.set('s', key);
  lookupUrl.searchParams.set('callsign', callsign);
  const lookupRes = await fetch(lookupUrl, { headers: { 'User-Agent': 'LOGBOOCK-EQSL-EXPRESS/1.0' } });
  if (!lookupRes.ok) return { error: 'No se pudo consultar el indicativo en QRZ.' };
  const xml = await lookupRes.text();
  const lookupError = field(xml, 'Error');
  if (lookupError) return { error: lookupError };
  const foundCall = field(xml, 'call');
  if (!foundCall) return { error: 'QRZ no devolvió un registro para ese indicativo.' };
  const first = field(xml, 'fname');
  const last = field(xml, 'name');
  return {
    callsign: foundCall,
    name: [first, last].filter(Boolean).join(' '),
    email: field(xml, 'email'),
    country: field(xml, 'country'),
    grid: field(xml, 'grid'),
    source: 'qrz-api',
  };
}
