# LOGBOOCK EQSL EXPRESS — Requisitos acordados y criterios de aceptación

Fecha de actualización: 22 de octubre de 2026

Este documento conserva todos los objetivos acordados para el proyecto. Es una lista de aceptación; que un punto figure aquí no significa que ya esté implementado o validado.

## 1. Identidad y crédito
- El indicativo `LU1TSB` debe aparecer únicamente en el pie de página como crédito de autoría, no como indicativo predeterminado del operador, en formularios, contactos de ejemplo ni firma automática de QSO/eQSL.
- El crédito visible debe decir `Desarrollado por LU1TSB · LOGBOOCK EQSL EXPRESS`.
- No se puede prometer que el crédito sea técnicamente inmodificable dentro de una copia del código. La protección práctica exige que el propietario conserve el control exclusivo del repositorio GitHub, la cuenta de despliegue y sus permisos, y que no se conceda acceso de edición sin autorización.

## 2. QRZ y datos de contacto
- Al introducir un indicativo, la aplicación debe consultar automáticamente una fuente autorizada si el usuario configuró correctamente sus credenciales y el servicio lo permite.
- Completar solamente los campos que la fuente devuelva de verdad; no deducir ni inventar emails, números, países o locators.
- Mostrar `NOT FOUND` si no se encuentra correo ni número móvil/WhatsApp disponible y permitir guardar el QSO de todos modos.
- La API XML de QRZ no garantiza un campo de WhatsApp. Si QRZ no devuelve un número móvil, la aplicación permite introducirlo manualmente; no debe asumir que un teléfono fijo es WhatsApp.
- El acceso a campos de QRZ depende de los permisos y del nivel de acceso que QRZ conceda a la cuenta. La aplicación no puede saltarse esas restricciones.
- La consulta de contactos antiguos que no tengan correo debe poder ejecutarse mediante una acción de reconsulta explícita o un proceso controlado, respetando límites y permisos de la fuente.

## 3. Envío de eQSL
- Si hay correo, ofrecer preparar el envío por email.
- Si hay un número móvil válido, ofrecer preparar el envío por WhatsApp.
- Si ambos están disponibles, el usuario decide qué canal usar.
- Si ninguno está disponible, informar `NOT FOUND` y dejar guardar el QSO sin enviar.
- Preparar el mensaje no equivale a enviarlo. El usuario revisa destinatario y mensaje y confirma el envío desde su aplicación de correo o WhatsApp.
- No marcar una QSL como enviada automáticamente sin confirmación del usuario.

## 4. Privacidad y separación de datos
- Los registros, configuraciones y credenciales de cada operador no deben mezclarse con los de otros operadores.
- La separación local por indicativo no es autenticación. Para ofrecer cuentas reales, recuperación de contraseña y sincronización entre dispositivos se necesita autenticación y un backend/base de datos con reglas de acceso por usuario.
- No guardar contraseñas o secretos en el repositorio. Usar variables seguras del servidor cuando corresponda.
- La arquitectura de almacenamiento local debe mostrar claramente que los datos se conservan en ese navegador y recomendar exportaciones ADIF de respaldo.

## 5. Formatos e integraciones
- ADIF: importar y exportar, validando que fechas, horas, bandas, frecuencias, modos e indicativos se conserven.
- Cabrillo: importar y exportar líneas QSO comunes. Antes de presentar un archivo a un concurso, revisar sus intercambios, categorías y reglas específicas; el modelo actual no guarda todos los campos de intercambio.
- QRZ: probar credenciales válidas, datos disponibles, `NOT FOUND`, errores de red y permisos.
- HamQTH: probar solamente con cuenta configurada y respetando lo que su API devuelve.
- eQSL y LoTW: probar los flujos autorizados, los mensajes de error y el manejo de confirmaciones.

## 6. Comprobaciones obligatorias antes de publicar
1. Instalar dependencias en un entorno compatible con la versión de Node indicada por Vite.
2. Ejecutar `npm run build` y corregir todos los errores.
3. Ejecutar `npm run lint` y revisar los errores relevantes.
4. Probar Android: formularios, teclado, navegación, botones, instalación PWA y persistencia.
5. Probar ADIF/Cabrillo con archivos reales de prueba y comprobar los datos antes y después.
6. Probar QRZ/HamQTH con cuentas autorizadas sin exponer contraseñas en el repositorio.
7. Probar los estados de correo/WhatsApp: ambos disponibles, solo correo, solo móvil y ninguno (`NOT FOUND`).
8. Probar aislamiento de usuarios. No declarar que hay cuentas independientes hasta que autenticación y almacenamiento seguro estén implementados.
9. Verificar que el crédito LU1TSB solo aparezca en el pie de página.
10. Revisar variables de entorno, permisos del repositorio, HTTPS, copias de seguridad y despliegue de prueba.

## Estado honesto de esta copia
- Incluye el código disponible para libro de guardia, ADIF, Cabrillo, consultas QRZ/HamQTH y preparación de email/WhatsApp.
- Se actualizó el mensaje del formulario para mostrar `NOT FOUND` cuando la consulta termina sin correo ni móvil/WhatsApp.
- El libro se guarda localmente por indicativo; esto no equivale a cuentas autenticadas ni sincronización en la nube.
- La API XML de QRZ no garantiza obtener WhatsApp y puede limitar campos según los permisos de la cuenta.
- No se debe considerar la compilación ni las pruebas de extremo a extremo aprobadas hasta ejecutar y registrar esas pruebas en un entorno con dependencias disponibles.
