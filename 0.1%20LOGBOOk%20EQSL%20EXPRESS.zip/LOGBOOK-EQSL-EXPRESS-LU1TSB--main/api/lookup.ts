import { lookupCallsign } from '../server/qrzLookup.mjs';

export default async function handler(req: any, res: any) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }
  try {
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});
    const result = await lookupCallsign(body);
    return res.status(result.error ? 400 : 200).json(result);
  } catch {
    return res.status(502).json({ error: 'No se pudo consultar QRZ en este momento.' });
  }
}
