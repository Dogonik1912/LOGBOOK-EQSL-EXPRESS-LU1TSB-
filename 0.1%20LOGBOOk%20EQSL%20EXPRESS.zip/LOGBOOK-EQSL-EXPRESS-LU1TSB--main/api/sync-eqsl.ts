export default async function handler(req: any, res: any) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return res.status(405).json({ error: 'Method not allowed' }); }
  try {
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});
    const username = String(body.user || '').trim();
    const password = String(body.pass || '');
    if (!username || !password) return res.status(400).json({ error: 'Ingresá usuario eQSL y contraseña.' });
    const params = new URLSearchParams({ UserName: username, Password: password, RcvdSince: String(body.since || '200001010000') });
    const inbox = await fetch(`https://www.eqsl.cc/qslcard/DownloadInBox.cfm?${params.toString()}`, { headers: { 'User-Agent': 'LOGBOOCK-EQSL-EXPRESS/1.0' } });
    if (!inbox.ok) return res.status(502).json({ error: 'eQSL.cc no respondió correctamente.' });
    const html = await inbox.text();
    if (!html.includes('Your ADIF log file has been built')) return res.status(400).json({ error: 'eQSL.cc no confirmó la descarga. Verificá las credenciales o la cuenta.' });
    const links = [...html.matchAll(/href\s*=\s*["']([^"']+\.(?:adi|txt)(?:\?[^"']*)?)["']/gi)].map((m) => m[1]);
    if (!links.length) return res.status(502).json({ error: 'eQSL.cc confirmó el proceso, pero no se encontró el archivo ADIF.' });
    const fileUrl = new URL(links[0], 'https://www.eqsl.cc/qslcard/');
    const file = await fetch(fileUrl, { headers: { 'User-Agent': 'LOGBOOCK-EQSL-EXPRESS/1.0' } });
    if (!file.ok) return res.status(502).json({ error: 'No se pudo descargar el ADIF de eQSL.cc.' });
    const adif = await file.text();
    if (!/<EOR\s*>/i.test(adif)) return res.status(200).json({ adif: '', count: 0, message: 'No hay confirmaciones eQSL nuevas.' });
    return res.status(200).json({ adif, count: (adif.match(/<EOR\s*>/gi) || []).length, message: 'Buzón de entrada de eQSL sincronizado.' });
  } catch {
    return res.status(502).json({ error: 'No se pudo sincronizar eQSL.cc en este momento.' });
  }
}
