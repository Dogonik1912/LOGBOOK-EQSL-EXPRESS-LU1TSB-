export default async function handler(req: any, res: any) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return res.status(405).json({ error: 'Method not allowed' }); }
  try {
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});
    const username = String(body.user || '').trim();
    const password = String(body.pass || '');
    if (!username || !password) return res.status(400).json({ error: 'Ingresá usuario y contraseña de LoTW.' });
    const params = new URLSearchParams({ login: username, password, qso_query: '1', qso_qsl: 'yes' });
    if (body.since) params.set('qso_qslsince', String(body.since));
    const upstream = await fetch(`https://lotw.arrl.org/lotwuser/lotwreport.adi?${params.toString()}`, { headers: { 'User-Agent': 'LOGBOOCK-EQSL-EXPRESS/1.0' } });
    if (!upstream.ok) return res.status(502).json({ error: 'LoTW no respondió correctamente.' });
    const adif = await upstream.text();
    if (!/<EOH\s*>/i.test(adif)) return res.status(400).json({ error: 'LoTW no devolvió ADIF válido. Verificá las credenciales y el estado de la cuenta.' });
    const count = (adif.match(/<EOR\s*>/gi) || []).length;
    return res.status(200).json({ adif: count ? adif : '', count, message: count ? 'Confirmaciones LoTW descargadas.' : 'LoTW no devolvió confirmaciones nuevas.' });
  } catch {
    return res.status(502).json({ error: 'No se pudo sincronizar LoTW en este momento.' });
  }
}
