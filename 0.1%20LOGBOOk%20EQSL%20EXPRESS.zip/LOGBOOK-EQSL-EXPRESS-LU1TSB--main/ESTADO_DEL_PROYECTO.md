# LOGBOOCK EQSL EXPRESS — Versión 1.0 revisada (copia de trabajo)
Fecha: 22 de octubre de 2026
Archivo de trabajo revisado: `1.0LOGBOOK_EQSL_EXPRES_ACTUALIZADO.zip`
Respaldo original conservado por separado: `1.0LOGBOOK_EQSL_EXPRES.zip`

Este archivo registra el estado de trabajo para poder continuar aunque se interrumpa el chat.

## Implementado en el código actual (pendiente de validación completa)
- No precargar contactos de demostración.
- Dejar vacíos los datos del corresponsal que no hayan sido devueltos por una fuente consultada; no inferir email, teléfono, país o locator a partir del indicativo.
- Consulta QRZ mediante API XML oficial (requiere acceso habilitado en la cuenta) y alternativa HamQTH API v2 cuando el usuario configura el servicio.
- Importación/exportación ADIF.
- Importación/exportación Cabrillo (.cbr/.log), con lectura de líneas QSO estándar y exportación de registros existentes.
- Sincronización de confirmaciones LoTW de la cuenta propia y buzón de entrada eQSL mediante interfaces disponibles, con limitaciones de cada servicio.
- Preparación de eQSL para email o WhatsApp; se distingue preparar el mensaje de confirmar manualmente que el usuario lo envió.
- Interfaz adaptable y archivos de base PWA con nombre/icono LOGBOOCK EQSL EXPRESS.

## Aún pendiente
- Ejecutar `npm install` y `npm run build` en un entorno con acceso a dependencias y corregir cualquier error real de compilación. En este entorno, `npm install` agotó el tiempo de espera y `npm run build` no pudo ejecutarse porque Vite no está instalado; por tanto, la compilación sigue sin verificar.
- Pruebas funcionales de extremo a extremo con cuentas de prueba, sin incluir contraseñas en el repositorio.
- Implementar autenticación real (registro/inicio de sesión) y base de datos en nube para sincronización multi-dispositivo. La separación actual por indicativo es local al navegador y NO sustituye una cuenta autenticada.
- Revisar viabilidad y permisos para integraciones adicionales (por ejemplo Club Log u otros servicios), usando API/formatos oficiales.
- Completar y verificar traducciones a 25 idiomas.
- Publicar una URL de prueba HTTPS y comprobarla en Android y escritorio.

## Cómo continuar desde este punto
1. Extraer el ZIP.
2. En un entorno con Node.js, entrar en la carpeta `LOGBOOK-EQSL-EXPRESS-LU1TSB--main`.
3. Ejecutar `npm install` y luego `npm run build`; resolver errores antes de publicar.
4. Subir este código a un repositorio GitHub propio e importarlo en https://vercel.com/new, o usar otra plataforma compatible.
5. Configurar variables/secretos en el panel de hosting; nunca subir contraseñas, tokens ni claves privadas al ZIP o a GitHub.
6. Probar la URL de despliegue, y solo después continuar con las integraciones e idiomas.

## Importante
Este punto de control es el código fuente disponible, no una versión ya publicada. Aún no existe una URL pública de prueba confirmada. El repositorio GitHub original del usuario puede no contener estos cambios; este ZIP es la copia de trabajo más reciente disponible.


## Estado de validación de esta copia
- Esta versión se preparó a partir del ZIP de punto de control guardado en el historial del proyecto.
- `src/types.ts` define `DEFAULT_CALLSIGN` como `LU1TSB`.
- `src/App.tsx` inicia con el libro vacío si no hay registros guardados y filtra IDs de QSOs de ejemplo antiguos (`qso-1`, `qso-2`, `qso-3`).
- El texto `EA1EXP` que aparece en algunos formularios es un ejemplo de formato en el texto de ayuda (placeholder), no un indicativo guardado automáticamente como QSO.
- La compilación y las pruebas de extremo a extremo todavía no están confirmadas en este entorno.
- Esta versión no implementa aún autenticación multiusuario ni sincronización de datos en la nube; los QSOs se guardan localmente en el navegador.


## Revisión adicional de la copia de trabajo
- El libro de guardia ahora se guarda bajo una clave local asociada al indicativo activo, para evitar mezclar QSOs al cambiar de indicativo en el mismo navegador.
- Los libros antiguos se migran al perfil LU1TSB cuando corresponda y se filtran los identificadores de demostración conocidos.
- Si el almacenamiento falla, la aplicación avisa al usuario para que exporte un respaldo ADIF.
- Se actualizó la versión de caché de la PWA y se excluyeron las rutas `/api/` de la caché del service worker.
- No se ha añadido autenticación real, almacenamiento en la nube ni sincronización multi-dispositivo; requieren un backend y configuración segura.
- No se ha confirmado compilación ni pruebas funcionales por falta de dependencias instalables en este entorno.


## Crédito de autoría y configuración de indicativo (22/10/2026)
- `LU1TSB` queda como crédito visible únicamente en el pie de la aplicación.
- Se eliminó como indicativo predeterminado, ejemplos de formularios, firmas automáticas y marcas de agua de tarjetas generadas.
- El operador debe configurar su propio indicativo.
- La protección efectiva del crédito en producción depende de que el propietario mantenga control exclusivo de GitHub y Vercel; no puede garantizarse que nadie modifique una copia local del código.


## Cabrillo añadido (22/10/2026)
- Se añadió `src/services/cabrillo.ts` para interpretar líneas `QSO:` de archivos Cabrillo habituales y convertirlas al modelo QSO de la aplicación.
- El Live Log incorpora botones para importar y exportar `.cbr`, `.log` y `.txt`.
- Limitación: el modelo actual no guarda intercambios específicos de concursos; la exportación usa el valor provisional `0` para esos campos y un encabezado genérico. Por eso, hay que revisar el archivo y adaptar las categorías/intercambios a las reglas del concurso antes de enviarlo como log oficial.
- La compilación sigue pendiente: `npm install` agotó el tiempo de espera en este entorno.


## Revisión de QRZ, correo y WhatsApp (22/10/2026)
- La consulta automática de indicativos se dispara al escribir un indicativo nuevo en el formulario, si el usuario configuró credenciales QRZ XML o HamQTH; completa solo campos devueltos por la fuente.
- QRZ documenta el campo `email` en su API XML, pero no un campo dedicado a WhatsApp. Por eso no es posible garantizar extracción automática de WhatsApp desde QRZ; la app no debe inferir que cualquier número es WhatsApp. Si el número no lo devuelve una fuente autorizada, el usuario lo introduce manualmente.
- El operador decide el canal al pulsar la acción de correo o WhatsApp. La aplicación prepara el mensaje; no lo envía silenciosamente ni debe marcarlo enviado sin confirmación del usuario.
- La consulta de QRZ requiere credenciales válidas y acceso habilitado a la API XML (la sesión web normal no equivale a acceso API). Fuente oficial: https://www.qrz.com/docs/xml/current_spec.html
- Aún deben probarse en despliegue real la autenticación API, los casos sin email, los números manuales y ambos flujos de envío. No declarar esta integración validada hasta completar esas pruebas.


## Requisitos consolidados (22/10/2026)
- Se añadió `REQUISITOS_Y_CRITERIOS_DE_ACEPTACION.md`, que reúne todos los objetivos acordados: QRZ, correo, WhatsApp, estado `NOT FOUND`, elección manual del canal de eQSL, aislamiento de datos, crédito LU1TSB, ADIF, Cabrillo, seguridad y pruebas antes de publicar.
- El formulario de nuevo QSO muestra ahora `NOT FOUND` si, tras la consulta, no hay correo ni móvil/WhatsApp disponible; el QSO se puede guardar igualmente.
- Este mensaje no significa que todos los objetivos estén terminados: autenticación real, sincronización segura en nube, pruebas con cuentas reales y compilación siguen pendientes de implementación/validación.
