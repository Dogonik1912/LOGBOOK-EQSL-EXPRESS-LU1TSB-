# Propiedad y crédito de autoría

El crédito visible de autoría de esta versión es **“Desarrollado por LU1TSB · LOGBOOCK EQSL EXPRESS”** y debe mostrarse únicamente en el pie de la página principal. No debe aparecer como indicativo predeterminado, ejemplo de formulario, firma automática ni marca de agua de tarjetas eQSL. Cada operador debe introducir su propio indicativo.

## Protección de cambios

Este archivo deja documentada la condición del proyecto, pero no constituye por sí solo una barrera técnica ni una garantía legal. Para impedir que terceros cambien el crédito en la versión publicada, el propietario debe conservar el control exclusivo del repositorio GitHub, del proyecto Vercel y de las credenciales de despliegue; no se deben conceder permisos de escritura o administración a terceros sin autorización. Un usuario que obtenga el código fuente y tenga permisos suficientes siempre podría modificar una copia.
