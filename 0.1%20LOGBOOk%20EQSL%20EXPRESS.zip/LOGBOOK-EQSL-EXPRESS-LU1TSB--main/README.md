# LOGBOOCK EQSL EXPRESS

Libro de guardia web para radioaficionados, creado para LU1TSB.

## Funciones incluidas

- Registro de QSOs y persistencia local en el navegador.
- Sin contactos de demostración precargados; los datos que no se encuentran quedan vacíos.
- Consulta de indicativos mediante la API XML oficial de QRZ y alternativa HamQTH API v2 cuando el usuario configura ambas fuentes. La cuenta QRZ debe disponer del acceso necesario. La consulta no infiere correo, teléfono, país ni grid por prefijos.
- Credenciales de QRZ mantenidas solo en `sessionStorage` durante la sesión del navegador y enviadas al endpoint del servidor por POST, no en la URL de la app.
- Exportación e importación ADIF para intercambiar logs con servicios compatibles.
- Accesos oficiales a QRZ.com, LoTW, eQSL.cc, Club Log y HamQTH.
- Sincronización de buzón de entrada eQSL y confirmaciones LoTW mediante sus interfaces oficiales, con credenciales temporales de sesión; si hay credenciales guardadas en la sesión del navegador, se intenta sincronizar al abrir la app.
- Preparación de eQSL por email o WhatsApp; se valida el correo/número y el estado enviado solo se marca tras confirmación manual. Descargar un PNG no equivale a enviar una tarjeta.
- Interfaz responsive y base instalable como PWA en Android y escritorio.

## Límites conocidos

- El log se guarda en el navegador actual. No hay sincronización automática entre dispositivos ni acceso a todos los registros de LoTW/eQSL.cc/Club Log. Se sincronizan las confirmaciones permitidas de la cuenta propia de LoTW y el buzón de entrada de eQSL; el resto del intercambio se realiza por ADIF.
- Los enlaces de servicios abren los sitios oficiales y conservan las sesiones que gestione el propio navegador. No transfieren credenciales ni significan que esas cuentas estén conectadas a esta app.
- QRZ XML API requiere que la cuenta tenga acceso habilitado. La app solo usa datos devueltos por la API y no extrae datos mediante scraping.
- Los enlaces `mailto:` y WhatsApp preparan un mensaje. El usuario debe enviarlo desde su aplicación; el sistema no puede verificar la entrega.
- Las traducciones a 25 idiomas quedan pendientes para la siguiente fase, una vez completada la validación funcional.

## Pruebas locales

```bash
npm install
npm run dev
npm run build
```

## Publicación de prueba con Vercel

1. Subir este proyecto a un repositorio GitHub propio.
2. Importar el repositorio en https://vercel.com/new.
3. Vercel detecta Vite, genera el contenido estático y publica la función `api/lookup`.
4. Probar la aplicación desde la URL HTTPS generada. Para QRZ, introducir credenciales solo si la cuenta tiene acceso a la API XML.

La publicación requiere completar estos pasos desde una cuenta de hosting. Este repositorio ZIP no contiene credenciales de despliegue ni una URL publicada.


## Nota sobre perfiles y privacidad
La copia de trabajo separa los libros locales por indicativo dentro del mismo navegador. Esto ayuda a no mezclar registros cuando se cambia de indicativo, pero no es un sistema de cuentas: no ofrece inicio de sesión seguro ni sincronización entre dispositivos. No uses este comportamiento como protección de datos confidenciales y exporta copias ADIF periódicas. La autenticación multiusuario y la base de datos en nube quedan pendientes de configurar e implementar antes de anunciar esa función.


## Importación y exportación Cabrillo
El Live Log permite importar líneas QSO de archivos `.cbr`, `.log` o `.txt` compatibles y exportar los contactos en formato Cabrillo 3.0-style. La aplicación todavía no guarda los intercambios específicos de cada concurso: la exportación usa marcadores provisionales (`0`) y debe revisarse según las reglas del concurso antes de presentarse. ADIF sigue siendo el formato recomendado para respaldar e intercambiar el libro de guardia general.
