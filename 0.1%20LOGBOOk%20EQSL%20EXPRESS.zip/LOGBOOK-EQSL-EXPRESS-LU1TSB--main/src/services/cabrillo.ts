import type { QSO } from '../types';

function frequencyToMHz(raw: string): string {
  const value = Number(raw.replace(',', '.'));
  if (!Number.isFinite(value) || value <= 0) return '';
  return value >= 1000 ? (value / 1000).toFixed(3) : value.toFixed(3);
}

function frequencyToBand(raw: string): string {
  const mhz = Number(frequencyToMHz(raw));
  if (!Number.isFinite(mhz) || mhz <= 0) return '';
  const bands: Array<[number, number, string]> = [
    [1.8, 2.0, '160m'], [3.5, 4.0, '80m'], [5.0, 5.5, '60m'],
    [7.0, 7.3, '40m'], [10.1, 10.15, '30m'], [14.0, 14.35, '20m'],
    [18.068, 18.168, '17m'], [21.0, 21.45, '15m'], [24.89, 24.99, '12m'],
    [28.0, 29.7, '10m'], [50.0, 54.0, '6m'], [144.0, 148.0, '2m'],
    [420.0, 450.0, '70cm'],
  ];
  return bands.find(([min, max]) => mhz >= min && mhz <= max)?.[2] ?? '';
}

function normalizeMode(raw: string): string {
  const mode = raw.toUpperCase();
  if (['PH', 'PHONE', 'USB', 'LSB'].includes(mode)) return 'SSB';
  if (['RY', 'RTTY'].includes(mode)) return 'RTTY';
  if (['DG', 'DIGI', 'DATA'].includes(mode)) return 'FT8';
  return mode;
}

/** Imports common Cabrillo QSO lines. Contest exchanges are not stored by this app. */
export function parseCabrillo(content: string): QSO[] {
  const parsed: QSO[] = [];
  for (const line of content.split(/\r?\n/)) {
    if (!/^\s*QSO\s*:/i.test(line)) continue;
    const fields = line.replace(/^\s*QSO\s*:\s*/i, '').trim().split(/\s+/);
    if (fields.length < 10) continue;
    const [rawFrequency, rawMode, rawDate, rawTime] = fields;
    const dateMatch = rawDate.match(/^(\d{4})-(\d{2})-(\d{2})$/) ?? rawDate.match(/^(\d{4})(\d{2})(\d{2})$/);
    const timeDigits = rawTime.replace(/\D/g, '');
    if (!dateMatch || timeDigits.length < 4) continue;
    // Cabrillo: freq mode date time mycall rst-sent exch-sent dxcall rst-rcvd exch-rcvd
    const callsign = (fields[7] || '').toUpperCase();
    const frequency = frequencyToMHz(rawFrequency);
    const band = frequencyToBand(rawFrequency);
    if (!callsign || !frequency || !band) continue;
    parsed.push({
      id: `cabrillo-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      callsign,
      date: `${dateMatch[1]}-${dateMatch[2]}-${dateMatch[3]}`,
      time: `${timeDigits.slice(0, 2)}:${timeDigits.slice(2, 4)}`,
      band,
      frequency,
      mode: normalizeMode(rawMode),
      rstSent: fields[5] || '',
      rstRcvd: fields[8] || '',
      email: '',
      notes: 'Importado desde Cabrillo; los intercambios de concurso no se almacenan en el libro.',
    });
  }
  return parsed;
}

function cabrilloMode(mode: string): string {
  const normalized = mode.toUpperCase();
  if (['SSB', 'LSB', 'USB', 'PHONE', 'PH'].includes(normalized)) return 'PH';
  if (normalized === 'CW') return 'CW';
  if (['RTTY', 'RY'].includes(normalized)) return 'RY';
  if (normalized === 'AM') return 'AM';
  if (normalized === 'FM') return 'FM';
  return ['FT8', 'FT4', 'PSK31', 'JS8', 'D-STAR', 'DMR', 'SSTV'].includes(normalized) ? 'DG' : normalized;
}

function toKHz(frequencyMHz: string): string {
  const value = Number(frequencyMHz.replace(',', '.'));
  return Number.isFinite(value) && value > 0 ? String(Math.round(value * 1000)) : '';
}
function safeHeader(value: string): string { return value.replace(/[\r\n]+/g, ' ').trim(); }

/**
 * Exports Cabrillo 3.0-style QSO lines. This app does not store contest exchanges,
 * so exchange placeholders are "0". Review contest-specific rules before submitting.
 */
export function exportCabrillo(qsos: QSO[], callsign: string): string {
  const operator = safeHeader(callsign).toUpperCase() || 'NOCALL';
  const lines = [
    'START-OF-LOG: 3.0', `CALLSIGN: ${operator}`, 'CONTEST: GENERAL-LOG',
    'CATEGORY-OPERATOR: SINGLE-OP', 'CATEGORY-BAND: ALL', 'CATEGORY-MODE: MIXED',
    'CATEGORY-POWER: LOW', 'CATEGORY-STATION: FIXED', 'CATEGORY-ASSISTED: NON-ASSISTED',
    'CLAIMED-SCORE: 0', `OPERATORS: ${operator}`, 'CREATED-BY: LOGBOOCK EQSL EXPRESS',
    'SOAPBOX: Exportacion general; revisar intercambios y reglas antes de presentar a un concurso.',
  ];
  for (const qso of qsos) {
    const frequency = toKHz(qso.frequency);
    const date = qso.date;
    const time = qso.time.replace(':', '').slice(0, 4).padEnd(4, '0');
    const workedCall = safeHeader(qso.callsign).toUpperCase();
    if (!frequency || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !workedCall) continue;
    lines.push(`QSO: ${frequency.padStart(5, ' ')} ${cabrilloMode(qso.mode).padEnd(2, ' ')} ${date} ${time} ${operator} ${(qso.rstSent || '59').padEnd(3, ' ')} 0 ${workedCall} ${(qso.rstRcvd || '59').padEnd(3, ' ')} 0`);
  }
  lines.push('END-OF-LOG:');
  return `${lines.join('\r\n')}\r\n`;
}
