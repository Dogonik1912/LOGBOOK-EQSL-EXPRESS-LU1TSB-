/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CallsignDetails {
  callsign: string;
  name?: string;
  email?: string;
  whatsapp?: string;     // Dígitos limpios para wa.me (ej. 5493886067078)
  whatsappRaw?: string;  // Formato original (ej. 0054 9 388...)
  country?: string;
  grid?: string;
  city?: string;
  state?: string;
  bio?: string;
  source: 'qrz' | 'hamqth' | 'qrz+hamqth' | 'unavailable';
}

/**
 * Obtiene la firma dinámica del operador según la regla PRIORIDAD 1:
 * El indicativo del operador se configura individualmente.
 * const firma = `73 cordiales de ${callsign}`;
 * Si no hay indicativo configurado, se devuelve una cadena vacía.
 */
export function getFirma(): string {
  const callsign = localStorage.getItem('user_callsign') || '';
  return callsign ? `73 cordiales de ${callsign}` : '73 cordiales';
}

export function getUserCallsign(): string {
  return localStorage.getItem('user_callsign') || '';
}

/**
 * Consulta directorios autorizados QRZ.com y HamQTH.com. Los campos ausentes permanecen vacíos.
 */
export async function lookupQRZCallsign(call: string): Promise<CallsignDetails> {
  const cleanCall = call.trim().toUpperCase();
  if (!cleanCall) return { callsign: '', source: 'unavailable' };

  const qrzUser = sessionStorage.getItem('qrz_user') || '';
  const qrzPass = sessionStorage.getItem('qrz_pass') || '';
  const hamqthUser = sessionStorage.getItem('hamqth_user') || '';
  const hamqthPass = sessionStorage.getItem('hamqth_pass') || '';
  let qrzData: Partial<CallsignDetails> = {};
  let hamqthData: Partial<CallsignDetails> = {};

  if (qrzUser && qrzPass) {
    try {
      const res = await fetch('/api/lookup', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ call: cleanCall, user: qrzUser, pass: qrzPass }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data && !data.error) qrzData = {
          name: typeof data.name === 'string' ? data.name : '',
          email: typeof data.email === 'string' ? data.email : '',
          country: typeof data.country === 'string' ? data.country : '',
          grid: typeof data.grid === 'string' ? data.grid : '',
        };
      }
    } catch (err) { console.warn('QRZ lookup unavailable:', err); }
  }

  // HamQTH puede completar campos que QRZ no devuelve; no se mezclan datos inventados.
  const qrzHasAllFields = Boolean(qrzData.name && qrzData.email && qrzData.country && qrzData.grid);
  if (hamqthUser && hamqthPass && !qrzHasAllFields) {
    try {
      const res = await fetch('/api/lookup-hamqth', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ call: cleanCall, user: hamqthUser, pass: hamqthPass }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data && !data.error) hamqthData = {
          name: typeof data.name === 'string' ? data.name : '',
          email: typeof data.email === 'string' ? data.email : '',
          country: typeof data.country === 'string' ? data.country : '',
          grid: typeof data.grid === 'string' ? data.grid : '',
        };
      }
    } catch (err) { console.warn('HamQTH lookup unavailable:', err); }
  }

  const hasQRZ = [qrzData.name, qrzData.email, qrzData.country, qrzData.grid].some((value) => Boolean(value));
  const hasHamQTH = [hamqthData.name, hamqthData.email, hamqthData.country, hamqthData.grid].some((value) => Boolean(value));
  const merged = {
    callsign: cleanCall,
    name: qrzData.name || hamqthData.name || '',
    email: qrzData.email || hamqthData.email || '',
    country: qrzData.country || hamqthData.country || '',
    grid: qrzData.grid || hamqthData.grid || '',
    source: (hasQRZ && hasHamQTH ? 'qrz+hamqth' : hasQRZ ? 'qrz' : hasHamQTH ? 'hamqth' : 'unavailable') as CallsignDetails['source'],
  };
  return merged;
}
