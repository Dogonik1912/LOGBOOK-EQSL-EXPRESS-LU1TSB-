import type { QSO } from '../types';

function readField(record: string, fieldName: string): string {
  const escaped = fieldName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const match = record.match(new RegExp(`<${escaped}:(\\d+)(?::[^>]*)?>([^<]*)`, 'i'));
  return match ? match[2].trim() : '';
}

export function parseADIF(content: string, source: 'file' | 'eqsl' | 'lotw' = 'file'): QSO[] {
  const records = content.split(/<EOR\s*>/i);
  const parsed: QSO[] = [];
  for (const record of records) {
    if (!record.trim()) continue;
    const callsign = readField(record, 'CALL').toUpperCase();
    if (!callsign) continue;
    const rawDate = readField(record, 'QSO_DATE');
    const date = /^\d{8}$/.test(rawDate) ? `${rawDate.slice(0, 4)}-${rawDate.slice(4, 6)}-${rawDate.slice(6, 8)}` : '';
    const rawTime = readField(record, 'TIME_ON').replace(/[^0-9]/g, '');
    const time = rawTime.length >= 4 ? `${rawTime.slice(0, 2)}:${rawTime.slice(2, 4)}` : '';
    const band = readField(record, 'BAND').toLowerCase();
    const frequency = readField(record, 'FREQ');
    const mode = readField(record, 'MODE').toUpperCase();
    if (!date || !time || !band || !mode) continue;
    const eqslReceived = /^(Y|V)$/i.test(readField(record, 'EQSL_QSL_RCVD')) || /^(Y|V)$/i.test(readField(record, 'QSL_RCVD')) || source === 'eqsl';
    const lotwReceived = /^(Y|V)$/i.test(readField(record, 'LOTW_QSL_RCVD')) || source === 'lotw';
    parsed.push({
      id: `${source}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      callsign,
      date,
      time,
      band,
      frequency,
      mode,
      rstSent: source === 'eqsl' ? readField(record, 'RST_RCVD') : readField(record, 'RST_SENT'),
      rstRcvd: source === 'eqsl' ? readField(record, 'RST_SENT') : readField(record, 'RST_RCVD'),
      email: readField(record, 'EMAIL'),
      name: readField(record, 'NAME'),
      country: readField(record, 'COUNTRY'),
      grid: readField(record, 'GRIDSQUARE'),
      notes: readField(record, 'COMMENT') || readField(record, 'QSLMSG'),
      qslSent: /^(Y|V)$/i.test(readField(record, 'QSL_SENT')),
      qslRcvd: eqslReceived || lotwReceived,
    });
  }
  return parsed;
}
