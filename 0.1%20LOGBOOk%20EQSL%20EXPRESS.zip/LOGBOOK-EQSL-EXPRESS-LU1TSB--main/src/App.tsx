/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { QSO, DEFAULT_CALLSIGN } from './types';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { NewQSOForm } from './components/NewQSOForm';
import { LiveLog } from './components/LiveLog';
import { QRZLoginModal } from './components/QRZLoginModal';
import { UserSettingsModal } from './components/UserSettingsModal';
import { EQSLCardModal } from './components/EQSLCardModal';
import { ReplyEQSLModal } from './components/ReplyEQSLModal';
import { IntegrationsPanel } from './components/IntegrationsPanel';
import { Radio, Award, Globe, Zap, Send, Info, ArrowRightLeft } from 'lucide-react';



const getActiveCallsign = () => (localStorage.getItem('user_callsign') || '').trim().toUpperCase();
const getLogbookKey = (callsign: string) => `logbook_qsos_${callsign.replace(/[^A-Z0-9/]/g, '_')}`;

function loadQsosForCallsign(callsign: string): QSO[] {
  const key = getLogbookKey(callsign);
  let saved = localStorage.getItem(key);
  // Migrar el libro antiguo sin asignarlo a un indicativo predeterminado.
  if (!saved && !callsign) {
    saved = localStorage.getItem('logbook_qsos');
    if (saved) localStorage.setItem(key, saved);
  }
  if (!saved) return [];
  try {
    const parsed = JSON.parse(saved) as QSO[];
    if (!Array.isArray(parsed)) return [];
    // Eliminar únicamente los identificadores de demostración conocidos de versiones antiguas.
    const clean = parsed.filter((q) => q && !['qso-1', 'qso-2', 'qso-3'].includes(q.id));
    if (clean.length !== parsed.length) localStorage.setItem(key, JSON.stringify(clean));
    return clean;
  } catch (error) {
    console.error(`No se pudo leer el libro de ${callsign}`, error);
    return [];
  }
}

export default function App() {
  const [qsos, setQsos] = useState<QSO[]>(() => loadQsosForCallsign(getActiveCallsign()));

  const [isQRZModalOpen, setIsQRZModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [activeEQSLQSO, setActiveEQSLQSO] = useState<QSO | null>(null);
  const [isReplyModalOpen, setIsReplyModalOpen] = useState(false);
  const [replyData, setReplyData] = useState<{
    replyToCall: string;
    myCall?: string;
    date?: string;
    time?: string;
    band?: string;
    frequency?: string;
    mode?: string;
    rst?: string;
    email?: string;
    whatsapp?: string;
  } | null>(null);
  const [, setRefreshKey] = useState(0);

  // PRIORIDAD 4: Al cargar la app, si NO existen en localStorage las claves 'qrz_user' y 'qrz_pass'
  // y 'qrz_skipped' no existe, mostrar el modal de aviso
  // Y verificar si se abrió mediante un enlace de responder eQSL (?reply_to=...)
  useEffect(() => {
    // Eliminar credenciales antiguas que versiones previas guardaban de forma permanente.
    localStorage.removeItem('qrz_user');
    localStorage.removeItem('qrz_pass');
    localStorage.removeItem('eqsl_user');
    localStorage.removeItem('eqsl_pass');
    localStorage.removeItem('lotw_user');
    localStorage.removeItem('lotw_pass');
    // Revisar si vino desde un enlace de respuesta compartida
    const urlParams = new URLSearchParams(window.location.search);
    const replyToParam = urlParams.get('reply_to');
    if (replyToParam) {
      setReplyData({
        replyToCall: replyToParam,
        myCall: urlParams.get('to_call') || '',
        date: urlParams.get('date') || '',
        time: urlParams.get('time') || '',
        band: urlParams.get('band') || '40m',
        frequency: urlParams.get('freq') || '7.120',
        mode: urlParams.get('mode') || 'SSB',
        rst: urlParams.get('rst') || '59',
        email: urlParams.get('email') || '',
        whatsapp: urlParams.get('wa') || '',
      });
      setIsReplyModalOpen(true);
    } else {
      const qrzUser = sessionStorage.getItem('qrz_user');
      const qrzPass = sessionStorage.getItem('qrz_pass');
      const qrzSkipped = sessionStorage.getItem('qrz_skipped');
      const hamqthUser = sessionStorage.getItem('hamqth_user');
      const hamqthPass = sessionStorage.getItem('hamqth_pass');

      if ((!qrzUser || !qrzPass) && (!hamqthUser || !hamqthPass) && !qrzSkipped) {
        setIsQRZModalOpen(true);
      }
    }

  }, []);

  // Guardar QSOs en localStorage cada vez que cambien
  const handleSaveQsos = (newQsos: QSO[]) => {
    setQsos(newQsos);
    try {
      localStorage.setItem(getLogbookKey(getActiveCallsign()), JSON.stringify(newQsos));
    } catch (error) {
      console.error('No se pudo guardar el libro de guardia', error);
      window.alert('No se pudieron guardar los contactos en este dispositivo. Exportá un respaldo ADIF y liberá espacio del navegador.');
    }
  };

  const handleAddQSO = (qso: QSO) => {
    const updated = [qso, ...qsos];
    handleSaveQsos(updated);
  };

  const handleUpdateQSO = (updatedQSO: QSO) => {
    const updated = qsos.map((q) => (q.id === updatedQSO.id ? updatedQSO : q));
    handleSaveQsos(updated);
  };

  const handleDeleteQSO = (id: string) => {
    if (window.confirm('¿Seguro que deseás eliminar este contacto del libro de guardia?')) {
      const updated = qsos.filter((q) => q.id !== id);
      handleSaveQsos(updated);
    }
  };

  const handleImportADIF = (importedQsos: QSO[]) => {
    const key = (q: QSO) => [q.callsign.trim().toUpperCase(), q.date, q.time, q.band, q.mode].join('|');
    const mergeRecord = (current: QSO, incoming: QSO): QSO => ({
      ...current,
      qslRcvd: Boolean(current.qslRcvd || incoming.qslRcvd),
      qslSent: Boolean(current.qslSent || incoming.qslSent),
      email: current.email || incoming.email,
      name: current.name || incoming.name,
      country: current.country || incoming.country,
      grid: current.grid || incoming.grid,
      notes: current.notes || incoming.notes,
    });
    const existingByKey = new Map(qsos.map((q) => [key(q), q]));
    const newByKey = new Map<string, QSO>();
    let mergedCount = 0;
    for (const incoming of importedQsos) {
      const k = key(incoming);
      const existing = existingByKey.get(k);
      if (existing) { existingByKey.set(k, mergeRecord(existing, incoming)); mergedCount++; continue; }
      const alreadyImported = newByKey.get(k);
      if (alreadyImported) { newByKey.set(k, mergeRecord(alreadyImported, incoming)); mergedCount++; }
      else newByKey.set(k, incoming);
    }
    const newRecords = [...newByKey.values()];
    handleSaveQsos([...newRecords, ...existingByKey.values()]);
    if (importedQsos.length) window.alert(`Sincronización terminada: ${newRecords.length} contactos nuevos y ${mergedCount} registros coincidentes actualizados.`);
  };

  const handleMarkEQSLSent = (id: string) => {
    const updated = qsos.map((q) => (q.id === id ? { ...q, qslSent: true } : q));
    handleSaveQsos(updated);
  };

  const handleSettingsUpdated = () => {
    // Al cambiar el indicativo, cambiar al libro local correspondiente a ese perfil.
    setQsos(loadQsosForCallsign(getActiveCallsign()));
    setRefreshKey((k) => k + 1);
  };

  // Estadísticas rápidas
  const uniqueCallsigns = new Set(qsos.map((q) => q.callsign)).size;
  const uniqueCountries = new Set(qsos.map((q) => q.country).filter(Boolean)).size;
  const eQslSentCount = qsos.filter((q) => q.qslSent).length;

  const handleOpenReplyForQSO = (qso: QSO) => {
    const myCurrentCall = localStorage.getItem('user_callsign') || '';
    setReplyData({
      replyToCall: qso.callsign,
      myCall: myCurrentCall,
      date: qso.date,
      time: qso.time,
      band: qso.band,
      frequency: qso.frequency,
      mode: qso.mode,
      rst: qso.rstRcvd || '59',
      email: qso.email,
      whatsapp: qso.whatsapp,
    });
    setIsReplyModalOpen(true);
  };

  const handleOpenManualReply = () => {
    const myCurrentCall = localStorage.getItem('user_callsign') || '';
    setReplyData({
      replyToCall: '',
      myCall: myCurrentCall,
      date: new Date().toISOString().slice(0, 10),
      time: '12:00',
      band: '40m',
      frequency: '7.120',
      mode: 'SSB',
      rst: '59',
    });
    setIsReplyModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Encabezado con reloj UTC, botón de WhatsApp y accesos */}
      <Header
        onOpenSettings={() => setIsSettingsModalOpen(true)}
        onOpenQRZModal={() => setIsQRZModalOpen(true)}
        onOpenReplyModal={handleOpenManualReply}
      />

      {/* Contenido Principal */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="mb-5 rounded-lg border border-amber-500/30 bg-amber-500/5 px-3 py-2 text-xs leading-relaxed text-amber-100" role="note">
          <strong>Respaldo y privacidad:</strong> esta versión guarda los contactos en el navegador de este dispositivo y separa los libros por indicativo. Esto no equivale todavía a una cuenta con contraseña ni sincroniza datos entre dispositivos; exportá ADIF periódicamente.
        </div>
        {/* Banner de resumen de estación */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 mb-6">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex items-center gap-3">
            <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-lg shrink-0">
              <Radio className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xl font-bold font-mono text-white">{qsos.length}</div>
              <div className="text-xs text-slate-400">Total QSOs</div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex items-center gap-3">
            <div className="p-2.5 bg-sky-500/10 text-sky-400 rounded-lg shrink-0">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xl font-bold font-mono text-white">{uniqueCallsigns}</div>
              <div className="text-xs text-slate-400">Indicativos únicos</div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-lg shrink-0">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xl font-bold font-mono text-white">{uniqueCountries}</div>
              <div className="text-xs text-slate-400">Países / DXCC</div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex items-center gap-3">
            <div className="p-2.5 bg-purple-500/10 text-purple-400 rounded-lg shrink-0">
              <Send className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xl font-bold font-mono text-white">{eQslSentCount}</div>
              <div className="text-xs text-slate-400">eQSLs Emitidas</div>
            </div>
          </div>
        </div>

        {/* Formulario de Nuevo QSO (con precarga de banda, fecha, hora y modo) */}
        <NewQSOForm
          onAddQSO={handleAddQSO}
          onOpenQRZModal={() => setIsQRZModalOpen(true)}
        />

        {/* Tabla Live Log (con columna Email editable, filtros y acciones) */}
        <LiveLog
          qsos={qsos}
          onUpdateQSO={handleUpdateQSO}
          onDeleteQSO={handleDeleteQSO}
          onOpenEQSL={(qso) => setActiveEQSLQSO(qso)}
          onImportADIF={handleImportADIF}
          onOpenReply={handleOpenReplyForQSO}
        />

        <IntegrationsPanel onImportADIF={handleImportADIF} />
      </main>

      {/* Crédito de autoría permanente en el pie de la aplicación. */}
      <Footer />

      {/* Modales */}
      {/* PRIORIDAD 4: Modal de Conexión QRZ */}
      <QRZLoginModal
        isOpen={isQRZModalOpen}
        onClose={() => setIsQRZModalOpen(false)}
        onSaved={() => {
          setRefreshKey((k) => k + 1);
        }}
      />

      {/* Modal de Configuración General */}
      <UserSettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        onUpdate={handleSettingsUpdated}
      />

      {/* Modal de Tarjeta eQSL Express */}
      <EQSLCardModal
        isOpen={Boolean(activeEQSLQSO)}
        qso={activeEQSLQSO}
        onClose={() => setActiveEQSLQSO(null)}
        onMarkSent={handleMarkEQSLSent}
        onOpenReply={handleOpenReplyForQSO}
      />

      {/* Modal de Responder con eQSL */}
      <ReplyEQSLModal
        isOpen={isReplyModalOpen}
        initialData={replyData}
        onClose={() => {
          setIsReplyModalOpen(false);
          setReplyData(null);
        }}
        onSaveQSO={handleAddQSO}
      />
    </div>
  );
}
