import React, { useEffect, useRef, useState } from 'react';
import { ExternalLink, RadioTower, Info, RefreshCw, ShieldCheck, Unplug } from 'lucide-react';
import type { QSO } from '../types';
import { parseADIF } from '../services/adif';

interface IntegrationsPanelProps { onImportADIF: (qsos: QSO[]) => void; }
type Service = 'eqsl' | 'lotw';

const services = [
  { name: 'QRZ.com', role: 'Directorio de indicativos', url: 'https://www.qrz.com/login', note: 'La búsqueda de indicativos usa la API XML oficial si tu cuenta tiene acceso habilitado.' },
  { name: 'eQSL.cc', role: 'Tarjetas y confirmaciones', url: 'https://www.eqsl.cc/qslcard/login.cfm', note: 'Podés sincronizar el buzón de entrada de eQSL durante esta sesión.' },
  { name: 'Logbook of The World (LoTW)', role: 'Confirmaciones ARRL', url: 'https://lotw.arrl.org/lotwuser/default', note: 'Podés consultar las confirmaciones LoTW asociadas a tu propia cuenta.' },
  { name: 'Club Log', role: 'Logbook y análisis DX', url: 'https://clublog.org/', note: 'Abrí el sitio oficial y usá ADIF para intercambiar contactos.' },
  { name: 'HamQTH', role: 'Directorio alternativo', url: 'https://www.hamqth.com/', note: 'Directorio independiente; la consulta directa requiere su integración y credenciales específicas.' },
];

export const IntegrationsPanel: React.FC<IntegrationsPanelProps> = ({ onImportADIF }) => {
  const callbackRef = useRef(onImportADIF);
  callbackRef.current = onImportADIF;
  const [eqslUser, setEqslUser] = useState(() => sessionStorage.getItem('eqsl_user') || '');
  const [eqslPass, setEqslPass] = useState(() => sessionStorage.getItem('eqsl_pass') || '');
  const [lotwUser, setLotwUser] = useState(() => sessionStorage.getItem('lotw_user') || '');
  const [lotwPass, setLotwPass] = useState(() => sessionStorage.getItem('lotw_pass') || '');
  const [hamqthUser, setHamqthUser] = useState(() => sessionStorage.getItem('hamqth_user') || '');
  const [hamqthPass, setHamqthPass] = useState(() => sessionStorage.getItem('hamqth_pass') || '');
  const [hamqthStatus, setHamqthStatus] = useState('');
  const [busy, setBusy] = useState<Service | null>(null);
  const [status, setStatus] = useState<Record<Service, string>>({ eqsl: '', lotw: '' });

  const sync = async (service: Service, supplied?: { user: string; pass: string }) => {
    const user = (supplied?.user ?? (service === 'eqsl' ? eqslUser : lotwUser)).trim();
    const pass = supplied?.pass ?? (service === 'eqsl' ? eqslPass : lotwPass);
    if (!user || !pass) {
      setStatus((prev) => ({ ...prev, [service]: 'Ingresá usuario y contraseña para sincronizar.' }));
      return;
    }
    sessionStorage.setItem(`${service}_user`, user);
    sessionStorage.setItem(`${service}_pass`, pass);
    setBusy(service);
    setStatus((prev) => ({ ...prev, [service]: 'Consultando el servicio oficial…' }));
    try {
      const endpoint = service === 'eqsl' ? '/api/sync-eqsl' : '/api/sync-lotw';
      const lastSyncKey = `${service}_last_sync`;
      const body: Record<string, string> = { user, pass };
      const lastSync = sessionStorage.getItem(lastSyncKey);
      if (lastSync) body.since = lastSync;
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await response.json();
      if (!response.ok || data.error) throw new Error(data.error || 'No se pudo completar la sincronización.');
      const parsed = data.adif ? parseADIF(data.adif, service) : [];
      if (parsed.length) callbackRef.current(parsed);
      const now = new Date();
      sessionStorage.setItem(lastSyncKey, service === 'eqsl'
        ? `${now.getUTCFullYear()}${String(now.getUTCMonth() + 1).padStart(2, '0')}${String(now.getUTCDate()).padStart(2, '0')}${String(now.getUTCHours()).padStart(2, '0')}${String(now.getUTCMinutes()).padStart(2, '0')}`
        : now.toISOString().replace('T', ' ').slice(0, 19));
      setStatus((prev) => ({ ...prev, [service]: `${data.message || 'Sincronización terminada.'} ${parsed.length ? `${parsed.length} registros procesados.` : ''}`.trim() }));
    } catch (error) {
      setStatus((prev) => ({ ...prev, [service]: error instanceof Error ? error.message : 'Error de sincronización.' }));
    } finally {
      setBusy(null);
    }
  };

  useEffect(() => {
    const eqslUserSaved = sessionStorage.getItem('eqsl_user');
    const eqslPassSaved = sessionStorage.getItem('eqsl_pass');
    const lotwUserSaved = sessionStorage.getItem('lotw_user');
    const lotwPassSaved = sessionStorage.getItem('lotw_pass');
    const autoSync = async () => {
      if (eqslUserSaved && eqslPassSaved) await sync('eqsl', { user: eqslUserSaved, pass: eqslPassSaved });
      if (lotwUserSaved && lotwPassSaved) await sync('lotw', { user: lotwUserSaved, pass: lotwPassSaved });
    };
    void autoSync();
    // Sincroniza una vez al abrir la app si las credenciales siguen en la sesión del navegador.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const disconnect = (service: Service) => {
    sessionStorage.removeItem(`${service}_user`);
    sessionStorage.removeItem(`${service}_pass`);
    sessionStorage.removeItem(`${service}_last_sync`);
    if (service === 'eqsl') { setEqslUser(''); setEqslPass(''); }
    else { setLotwUser(''); setLotwPass(''); }
    setStatus((prev) => ({ ...prev, [service]: 'Sesión local desconectada.' }));
  };

  return (
    <section className="mt-6 rounded-2xl border border-slate-800 bg-slate-900 p-5 sm:p-6 shadow-xl">
      <div className="flex items-start gap-3 mb-4">
        <div className="rounded-xl bg-sky-500/10 p-2.5 text-sky-400"><RadioTower className="h-5 w-5" /></div>
        <div>
          <h2 className="text-base font-bold text-white">Servicios de radioaficionados</h2>
          <p className="mt-1 text-xs text-slate-400">Las cuentas se consultan por los mecanismos oficiales disponibles. Las credenciales de eQSL y LoTW se guardan solo durante esta sesión del navegador; se envían por HTTPS para consultar las API oficiales y no se guardan de forma permanente en la aplicación.</p>
        </div>
      </div>

      <div className="mb-4 rounded-xl border border-emerald-500/20 bg-slate-950/70 p-4">
        <div className="flex items-center justify-between gap-2"><h3 className="font-semibold text-white">HamQTH · Directorio alternativo</h3><a href="https://www.hamqth.com/" target="_blank" rel="noopener noreferrer" className="text-emerald-300"><ExternalLink className="h-4 w-4" /></a></div>
        <p className="mt-1 text-xs leading-5 text-slate-400">Registrate en HamQTH y guardá tus credenciales solo para esta sesión. Si QRZ no devuelve datos, la app intentará consultar HamQTH. Datos proporcionados por HamQTH.com.</p>
        <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2">
          <input aria-label="Usuario HamQTH" autoComplete="username" value={hamqthUser} onChange={(e) => setHamqthUser(e.target.value)} placeholder="Usuario / indicativo HamQTH" className="min-w-0 rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white" />
          <input aria-label="Contraseña HamQTH" autoComplete="current-password" type="password" value={hamqthPass} onChange={(e) => setHamqthPass(e.target.value)} placeholder="Contraseña HamQTH" className="min-w-0 rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white" />
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <button type="button" onClick={() => { if (!hamqthUser.trim() || !hamqthPass) { setHamqthStatus('Ingresá usuario y contraseña de HamQTH.'); return; } sessionStorage.setItem('hamqth_user', hamqthUser.trim()); sessionStorage.setItem('hamqth_pass', hamqthPass); setHamqthStatus('Credenciales guardadas en esta sesión. Se validarán al consultar un indicativo.'); }} className="inline-flex items-center gap-2 rounded-lg bg-emerald-700 px-3 py-2 text-xs font-semibold text-white"><ShieldCheck className="h-3.5 w-3.5" />Guardar sesión</button>
          <button type="button" onClick={() => { sessionStorage.removeItem('hamqth_user'); sessionStorage.removeItem('hamqth_pass'); setHamqthUser(''); setHamqthPass(''); setHamqthStatus('Sesión local desconectada.'); }} className="inline-flex items-center gap-1 rounded-lg border border-slate-700 px-3 py-2 text-xs text-slate-300"><Unplug className="h-3.5 w-3.5" />Desconectar</button>
        </div>
        {hamqthStatus && <p role="status" className="mt-2 text-xs leading-5 text-amber-200">{hamqthStatus}</p>}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 mb-4">
        <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-4">
          <div className="flex items-center justify-between gap-2"><h3 className="font-semibold text-white">Sincronizar eQSL.cc</h3><a href="https://www.eqsl.cc/qslcard/login.cfm" target="_blank" rel="noopener noreferrer" className="text-sky-300"><ExternalLink className="h-4 w-4" /></a></div>
          <p className="mt-1 text-xs leading-5 text-slate-400">Descarga las eQSL entrantes en ADIF e intenta actualizar el libro. No sube QSOs ni envía tarjetas.</p>
          <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2">
            <input aria-label="Usuario eQSL" autoComplete="username" value={eqslUser} onChange={(e) => setEqslUser(e.target.value)} placeholder="Usuario / indicativo" className="min-w-0 rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white" />
            <input aria-label="Contraseña eQSL" autoComplete="current-password" type="password" value={eqslPass} onChange={(e) => setEqslPass(e.target.value)} placeholder="Contraseña eQSL" className="min-w-0 rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white" />
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <button type="button" disabled={busy !== null} onClick={() => void sync('eqsl')} className="inline-flex items-center gap-2 rounded-lg bg-sky-600 px-3 py-2 text-xs font-semibold text-white disabled:opacity-50"><RefreshCw className={`h-3.5 w-3.5 ${busy === 'eqsl' ? 'animate-spin' : ''}`} />{busy === 'eqsl' ? 'Sincronizando…' : 'Guardar y sincronizar'}</button>
            <button type="button" onClick={() => disconnect('eqsl')} className="inline-flex items-center gap-1 rounded-lg border border-slate-700 px-3 py-2 text-xs text-slate-300"><Unplug className="h-3.5 w-3.5" />Desconectar</button>
          </div>
          {status.eqsl && <p role="status" className="mt-2 text-xs leading-5 text-amber-200">{status.eqsl}</p>}
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-4">
          <div className="flex items-center justify-between gap-2"><h3 className="font-semibold text-white">Sincronizar LoTW</h3><a href="https://lotw.arrl.org/lotwuser/default" target="_blank" rel="noopener noreferrer" className="text-sky-300"><ExternalLink className="h-4 w-4" /></a></div>
          <p className="mt-1 text-xs leading-5 text-slate-400">Consulta las confirmaciones de tu propia cuenta LoTW. No accede al libro privado de otros usuarios.</p>
          <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2">
            <input aria-label="Usuario LoTW" autoComplete="username" value={lotwUser} onChange={(e) => setLotwUser(e.target.value)} placeholder="Usuario / indicativo" className="min-w-0 rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white" />
            <input aria-label="Contraseña LoTW" autoComplete="current-password" type="password" value={lotwPass} onChange={(e) => setLotwPass(e.target.value)} placeholder="Contraseña LoTW" className="min-w-0 rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white" />
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <button type="button" disabled={busy !== null} onClick={() => void sync('lotw')} className="inline-flex items-center gap-2 rounded-lg bg-sky-600 px-3 py-2 text-xs font-semibold text-white disabled:opacity-50"><RefreshCw className={`h-3.5 w-3.5 ${busy === 'lotw' ? 'animate-spin' : ''}`} />{busy === 'lotw' ? 'Sincronizando…' : 'Guardar y sincronizar'}</button>
            <button type="button" onClick={() => disconnect('lotw')} className="inline-flex items-center gap-1 rounded-lg border border-slate-700 px-3 py-2 text-xs text-slate-300"><Unplug className="h-3.5 w-3.5" />Desconectar</button>
          </div>
          {status.lotw && <p role="status" className="mt-2 text-xs leading-5 text-amber-200">{status.lotw}</p>}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
        {services.map((service) => (
          <article key={service.name} className="rounded-xl border border-slate-800 bg-slate-950/70 p-4">
            <div className="flex items-start justify-between gap-3">
              <div><h3 className="font-semibold text-white">{service.name}</h3><p className="mt-0.5 text-[11px] text-amber-300">{service.role}</p></div>
              <a href={service.url} target="_blank" rel="noopener noreferrer" aria-label={`Abrir ${service.name}`} className="rounded-lg p-2 text-sky-400 hover:bg-slate-800"><ExternalLink className="h-4 w-4" /></a>
            </div>
            <p className="mt-3 text-xs leading-5 text-slate-400">{service.note}</p>
            <a href={service.url} target="_blank" rel="noopener noreferrer" className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-sky-300 hover:text-sky-200">Abrir sitio oficial <ExternalLink className="h-3 w-3" /></a>
          </article>
        ))}
      </div>
      <div className="mt-4 flex items-start gap-2 rounded-xl border border-amber-500/20 bg-amber-500/5 p-3 text-xs leading-5 text-slate-300">
        <Info className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" />
        <p><strong className="text-amber-200">Alcance de la sincronización:</strong> el libro local se guarda en este navegador. QRZ y HamQTH consultan datos del directorio que cada servicio devuelve según sus permisos; eQSL y LoTW sincronizan buzón/confirmaciones de la cuenta propia. Club Log y HamQTH se abren en sus sitios oficiales. Para intercambiar registros entre plataformas, usá <strong>Exportar ADIF</strong> e <strong>Importar ADIF</strong>. No se descargan emails, teléfonos ni datos privados de otros operadores.</p>
      </div>
    </section>
  );
};
