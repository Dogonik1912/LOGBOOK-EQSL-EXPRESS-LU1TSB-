import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';
import { lookupCallsign } from './server/qrzLookup.mjs';
import syncEqsl from './api/sync-eqsl';
import syncLotw from './api/sync-lotw';
import lookupHamQTH from './api/lookup-hamqth';

async function readJsonBody(req: any): Promise<any> {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk: Buffer) => { body += chunk.toString(); if (body.length > 20000) reject(new Error('Body too large')); });
    req.on('end', () => { try { resolve(JSON.parse(body || '{}')); } catch { reject(new Error('Invalid JSON')); } });
    req.on('error', reject);
  });
}

export default defineConfig(() => ({
  plugins: [
    react(),
    tailwindcss(),
    {
      name: 'qrz-lookup-api-dev',
      configureServer(server) {
        server.middlewares.use('/api/lookup', async (req: any, res: any) => {
          res.setHeader('Content-Type', 'application/json; charset=utf-8');
          res.setHeader('Cache-Control', 'no-store');
          if (req.method !== 'POST') {
            res.statusCode = 405;
            res.setHeader('Allow', 'POST');
            res.end(JSON.stringify({ error: 'Method not allowed' }));
            return;
          }
          try {
            const body = await readJsonBody(req);
            const result = await lookupCallsign(body);
            res.statusCode = result.error ? 400 : 200;
            res.end(JSON.stringify(result));
          } catch {
            res.statusCode = 502;
            res.end(JSON.stringify({ error: 'No se pudo consultar QRZ en este momento.' }));
          }
        });
        const mountApi = (route: string, handler: (req: any, res: any) => Promise<any>) => {
          server.middlewares.use(route, async (req: any, res: any) => {
            res.setHeader('Content-Type', 'application/json; charset=utf-8');
            res.setHeader('Cache-Control', 'no-store');
            if (req.method !== 'POST') { res.statusCode = 405; res.setHeader('Allow', 'POST'); res.end(JSON.stringify({ error: 'Method not allowed' })); return; }
            try {
              const body = await readJsonBody(req);
              const responseAdapter: any = {
                code: 200,
                setHeader: (name: string, value: string) => res.setHeader(name, value),
                status(code: number) { this.code = code; return this; },
                json(data: any) { res.statusCode = this.code; res.setHeader('Content-Type', 'application/json; charset=utf-8'); res.end(JSON.stringify(data)); return this; },
              };
              await handler({ method: req.method, body }, responseAdapter);
            } catch {
              if (!res.writableEnded) { res.statusCode = 502; res.end(JSON.stringify({ error: 'No se pudo completar la sincronización.' })); }
            }
          });
        };
        mountApi('/api/lookup-hamqth', lookupHamQTH as any);
        mountApi('/api/sync-eqsl', syncEqsl as any);
        mountApi('/api/sync-lotw', syncLotw as any);
      },
    },
  ],
  resolve: { alias: { '@': path.resolve(__dirname, '.') } },
  server: {
    hmr: process.env.DISABLE_HMR !== 'true',
    watch: process.env.DISABLE_HMR === 'true' ? null : {},
  },
}));
